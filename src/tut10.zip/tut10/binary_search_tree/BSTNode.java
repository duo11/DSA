package tut10.binary_search_tree;

public class BSTNode {
    int value;

    public BSTNode(int value) {
        this.value = value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    public int getValue()
    {
        return value;
    }
}
